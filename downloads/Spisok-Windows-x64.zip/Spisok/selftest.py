"""Offline Windows package health check; uses only synthetic names."""
import io
import sys
from pathlib import Path

# Isolated Python excludes script directory from sys.path by design.
sys.path.insert(0, str(Path(__file__).resolve().parent))
from docx import Document
from openpyxl import load_workbook
from converter import convert, make_excel, read_docx


def main():
    d = Document()
    d.add_paragraph('старшего лейтенанта Ивановой Анны Сергеевны, войсковая часть 00123;')
    stream = io.BytesIO()
    d.save(stream)
    rows, _ = convert(read_docx(stream.getvalue()))
    assert len(rows) == 1
    assert rows[0].surname == 'ИВАНОВА'
    assert rows[0].rank == 'старший лейтенант'
    rows, _ = convert(read_docx(stream.getvalue()), 'datv')
    assert rows[0].name == 'Анне'
    sheet = load_workbook(io.BytesIO(make_excel([p.json() for p in rows]))).active
    assert sheet.max_column == 5
    assert sheet['E2'].value == '00123'
    print('OK: Word, local dictionaries, female names, both cases, Excel and leading zeroes.')


if __name__ == '__main__':
    main()
