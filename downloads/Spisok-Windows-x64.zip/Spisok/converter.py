"""Offline extraction and case conversion. No network operations."""
from __future__ import annotations

import io
import re
import zipfile
from dataclasses import dataclass, asdict
from functools import lru_cache

import pymorphy3
from docx import Document
from openpyxl import Workbook
from openpyxl.styles import Alignment, Font, PatternFill

MAX_FILE_SIZE = 20 * 1024 * 1024
MAX_UNPACKED_SIZE = 100 * 1024 * 1024
CASES = {'nomn', 'datv'}
HEADERS = ['Звание', 'ФАМИЛИЯ', 'Имя', 'Отчество', 'Войсковая часть']
# Longest titles first so a generic "лейтенанта" cannot swallow a prefix.
RANK = re.compile(
    r'(?<![А-Яа-яЁё])(?:гвардии\s+)?(?:'
    r'(?:генерал[ -](?:полковника|лейтенанта|майора))|'
    r'(?:старшего\s+|младшего\s+)?(?:лейтенанта|сержанта|прапорщика)|'
    r'(?:старшего\s+)?(?:мичмана|матроса)|'
    r'капитана\s+[123123ⅠⅡⅢ]+(?:[ -]го)?\s+ранга|'
    r'адмирала\s+флота|вице[ -]адмирала|контр[ -]адмирала|'
    r'генерала\s+армии|маршала(?:\s+Российской\s+Федерации)?|'
    r'полковника|подполковника|майора|капитана|ефрейтора|рядового|'
    r'старшины|адмирала'
    r')(?:\s+(?:юстиции|медицинской\s+службы|ветеринарной\s+службы))?'
    r'(?:\s+(?:запаса|в\s+отставке))?(?![А-Яа-яЁё])', re.I)
WORD = r"[А-Яа-яЁёA-Za-zÀ-žӀІіЇїЄєҐґӘәӨөҮүҚқҒғҢңҺһҰұ][А-Яа-яЁёA-Za-zÀ-žӀІіЇїЄєҐґӘәӨөҮүҚқҒғҢңҺһҰұ'’\-]*"
NAME = re.compile(rf'^\s*({WORD})\s+({WORD})(?:\s+({WORD}))?(?=\s*[,;\d]|\s*$)', re.I)
UNIT = re.compile(r'(?:войсков\w*\s+част\w*|в\s*/\s*ч|в[.]?\s*ч[.]?)\s*(?:№\s*)?([0-9]+(?:[ -]?[А-Яа-яA-Za-z])?)', re.I)


@dataclass
class Person:
    rank: str
    surname: str
    name: str
    patronymic: str
    unit: str
    source: str = ''
    warning: str = ''

    def json(self):
        return asdict(self)


@lru_cache(maxsize=1)
def morph():
    return pymorphy3.MorphAnalyzer()


def title(s):
    return '-'.join(part[:1].upper() + part[1:].lower() for part in s.split('-'))


def gender_of(patronymic, name):
    p = patronymic.lower()
    if re.search(r'(?:овны|евны|ёвны|ичны|иничны)$', p):
        return 'femn'
    if re.search(r'(?:овича|евича|ёвича|ича)$', p):
        return 'masc'
    candidates = [p for p in morph().parse(name) if 'Name' in p.tag and p.is_known and p.tag.gender]
    genders = {p.tag.gender for p in candidates if p.tag.case == 'gent'}
    return genders.pop() if len(genders) == 1 else None


def inflect_name(word, kind, gender, case):
    if not word:
        return '', []
    # Hyphenated names and surnames: inflect each component independently.
    if '-' in word:
        converted = [inflect_name(w, kind, gender, case) for w in word.split('-')]
        return '-'.join(w for w, _ in converted), [m for _, msgs in converted for m in msgs]
    parses = [p for p in morph().parse(word) if kind in p.tag and (not gender or p.tag.gender in (gender, None))]
    genitives = [p for p in parses if p.tag.case == 'gent']
    if genitives:
        parses = genitives
    else:
        # Do not silently treat a nominative guess as a genitive source.
        return title(word), [f'Проверьте: {word} — родительный падеж не распознан']
    parses.sort(key=lambda p: (p.is_known, p.score), reverse=True)
    p = parses[0]
    out = p.inflect({case})
    if not out:
        return title(word), [f'Не удалось склонить: {word}']
    warnings = []
    if not p.is_known:
        warnings.append(f'Проверьте редкое ФИО: {word} (словарная догадка)')
    alternatives = {q.inflect({case}).word for q in parses if q.is_known and q.inflect({case})}
    if len(alternatives) > 1:
        warnings.append(f'Неоднозначное восстановление: {word}')
    result = out.word if 'ё' in word.lower() else out.word.replace('ё', 'е')
    return title(result), warnings


# Fixed parts are qualifiers whose case does not change with the military title.
FIXED = {'гвардии', 'юстиции', 'медицинской', 'ветеринарной', 'службы', 'запаса',
         'в', 'отставке', 'ранга', 'армии', 'флота', 'российской', 'федерации'}


def inflect_rank(rank, case):
    def change(m):
        word = m.group()
        if word.lower() in FIXED or word.lower() == 'го':
            return word.lower()
        candidates = [p for p in morph().parse(word) if p.tag.case == 'gent' and p.tag.number == 'sing']
        if not candidates:
            return word.lower()
        p = next((p for p in candidates if p.tag.gender == 'masc'), candidates[0])
        out = p.inflect({case, 'masc'}) if p.tag.POS in ('ADJF', 'PRTF') else p.inflect({case})
        return out.word if out else word.lower()
    result = re.sub(r'[А-Яа-яЁё]+', change, rank)
    return re.sub(r'российской\s+федерации', 'Российской Федерации', result)


def read_docx(data):
    if len(data) > MAX_FILE_SIZE:
        raise ValueError('Файл больше 20 МБ.')
    try:
        with zipfile.ZipFile(io.BytesIO(data)) as archive:
            if sum(x.file_size for x in archive.infolist()) > MAX_UNPACKED_SIZE:
                raise ValueError('Распакованный документ больше 100 МБ.')
        document = Document(io.BytesIO(data))
    except (zipfile.BadZipFile, KeyError) as e:
        raise ValueError('Нужен документ Word в формате .docx. Старый .doc сохраните как .docx.') from e
    # XML paragraph order includes table cells, while excluding deleted text.
    paragraphs = []
    ns = {'w': 'http://schemas.openxmlformats.org/wordprocessingml/2006/main'}
    for p in document.element.body.iter('{%s}p' % ns['w']):
        text = ''.join((' ' if node.tag.rsplit('}', 1)[-1] in ('tab', 'br', 'cr') else node.text or '')
                       for node in p.iter() if node.tag.rsplit('}', 1)[-1] in ('t', 'tab', 'br', 'cr'))
        if text.strip():
            paragraphs.append(text)
    return '\n'.join(paragraphs)


def convert(text, case='nomn'):
    if case not in CASES:
        raise ValueError('Допустимы только именительный и дательный падежи.')
    text = re.sub(r'\s+', ' ', text.replace('\xa0', ' ')).strip()
    matches = list(RANK.finditer(text))
    people = []
    issues = []
    if not matches:
        return [], ['Не найдены звания в родительном падеже. Проверьте текст документа. Скан-картинки не распознаются.']
    prefix = text[:matches[0].start()].strip()
    if prefix:
        issues.append('Текст до первой записи (проверьте, что это только заголовок): ' + prefix)
    for i, match in enumerate(matches):
        end = matches[i + 1].start() if i + 1 < len(matches) else len(text)
        source = text[match.start():end].strip(' ;')
        tail = text[match.end():end].strip(' ;')
        unit_match = UNIT.search(tail)
        fio = tail[:unit_match.start()] if unit_match else tail
        fio = fio.strip(' ,;')
        name_match = NAME.fullmatch(fio)
        if not name_match:
            # Never discard a recognized rank row. Keep the original for manual correction.
            people.append(Person(inflect_rank(match.group(), case), '', '', '',
                                 unit_match.group(1) if unit_match else '', source,
                                 'Не удалось выделить ФИО. Заполните поля по исходному тексту.'))
            continue
        surname, name, patronymic = name_match.groups()
        patronymic = patronymic or ''
        gender = gender_of(patronymic, name)
        warnings = []
        if not gender:
            warnings.append('Пол не определён однозначно; проверьте ФИО')
        fields = []
        for word, kind in [(surname, 'Surn'), (name, 'Name'), (patronymic, 'Patr')]:
            result, notes = inflect_name(word, kind, gender, case)
            fields.append(result)
            warnings.extend(notes)
        if not patronymic:
            warnings.append('Отчество отсутствует')
        if not unit_match:
            warnings.append('Войсковая часть не найдена')
        else:
            remainder = tail[unit_match.end():].strip(' ,;.')
            if remainder:
                warnings.append('После войсковой части есть дополнительный текст; проверьте исходную запись')
        people.append(Person(inflect_rank(match.group(), case), fields[0].upper(), fields[1], fields[2],
                             unit_match.group(1) if unit_match else '', source, '; '.join(dict.fromkeys(warnings))))
    return people, issues


def make_excel(rows):
    book = Workbook()
    sheet = book.active
    sheet.title = 'Список'
    sheet.append(HEADERS)
    for row in rows:
        values = [str(row.get(key, '')).strip() for key in ('rank', 'surname', 'name', 'patronymic', 'unit')]
        values[1] = values[1].upper()
        sheet.append(values)
        for cell in sheet[sheet.max_row]:
            # All five columns are literal text: keep leading zeroes and prevent formulas.
            cell.data_type = 's'
            cell.number_format = '@'
    for cell in sheet[1]:
        cell.font = Font(bold=True, color='FFFFFF')
        cell.fill = PatternFill('solid', fgColor='214F45')
    for col, width in zip('ABCDE', (35, 28, 23, 27, 22)):
        sheet.column_dimensions[col].width = width
    for row in sheet.iter_rows(min_row=2):
        for cell in row:
            cell.alignment = Alignment(vertical='top', wrap_text=True)
    sheet.freeze_panes = 'A2'
    sheet.auto_filter.ref = sheet.dimensions
    stream = io.BytesIO()
    book.save(stream)
    return stream.getvalue()
