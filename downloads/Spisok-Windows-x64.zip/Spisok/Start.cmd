@echo off
chcp 65001 >nul
setlocal
cd /d "%~dp0"
if not exist "runtime\python.exe" (
  echo Не найден встроенный Python. Распакуйте весь архив в одну папку.
  pause
  exit /b 1
)
"runtime\python.exe" -I launch.py
if errorlevel 1 (
  echo Не удалось запустить программу. Скопируйте сообщение об ошибке выше.
  pause
)
