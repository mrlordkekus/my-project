@echo off
chcp 65001 >nul
setlocal
cd /d "%~dp0"
"runtime\python.exe" -I selftest.py
pause
