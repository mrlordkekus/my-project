"""Local-only UI. The packaged Windows executable needs neither Python nor Internet."""
import argparse
import json
import secrets
import sys
import threading
import webbrowser
from http.server import BaseHTTPRequestHandler, HTTPServer
from pathlib import Path
from urllib.parse import urlsplit, parse_qs

from converter import MAX_FILE_SIZE, convert, make_excel, read_docx

ROOT = Path(getattr(sys, '_MEIPASS', Path(__file__).parent))


def create_server(port=0):
    token = secrets.token_urlsafe(32)

    class Handler(BaseHTTPRequestHandler):
        def log_message(self, *args):
            pass  # Documents and personal data must not appear in server logs.

        def reply(self, status, data, mime='application/json; charset=utf-8', attachment=False):
            self.send_response(status)
            self.send_header('Content-Type', mime)
            self.send_header('Content-Length', str(len(data)))
            self.send_header('Cache-Control', 'no-store')
            self.send_header('X-Content-Type-Options', 'nosniff')
            self.send_header('Content-Security-Policy', "default-src 'self'; script-src 'unsafe-inline'; style-src 'unsafe-inline'; connect-src 'self'; img-src 'self' data:; frame-ancestors 'none'")
            if attachment:
                self.send_header('Content-Disposition', 'attachment; filename="spisok.xlsx"')
            self.end_headers()
            self.wfile.write(data)

        def do_GET(self):
            if self.path != '/':
                self.reply(404, b'{}')
                return
            html = (ROOT / 'assets' / 'index.html').read_text(encoding='utf-8').replace('__TOKEN__', token)
            self.reply(200, html.encode(), 'text/html; charset=utf-8')

        def do_POST(self):
            if self.headers.get('X-App-Token') != token:
                self.reply(403, b'{}')
                return
            try:
                length = int(self.headers.get('Content-Length', '0'))
                if not 0 < length <= MAX_FILE_SIZE:
                    raise ValueError('Нужен непустой файл размером до 20 МБ.')
                self.connection.settimeout(30)
                data = self.rfile.read(length)
                url = urlsplit(self.path)
                if url.path == '/api/convert':
                    case = parse_qs(url.query).get('case', ['nomn'])[0]
                    people, issues = convert(read_docx(data), case)
                    result = {'rows': [p.json() for p in people], 'issues': issues, 'case': case}
                    self.reply(200, json.dumps(result, ensure_ascii=False).encode())
                elif url.path == '/api/export':
                    rows = json.loads(data)
                    if not isinstance(rows, list) or not rows or len(rows) > 10000:
                        raise ValueError('В таблице должно быть от 1 до 10000 записей.')
                    keys = ('rank', 'surname', 'name', 'patronymic', 'unit')
                    if any(not isinstance(r, dict) or any(not isinstance(r.get(k), str) or len(r[k]) > 1000 for k in keys) for r in rows):
                        raise ValueError('Некорректное содержимое таблицы.')
                    self.reply(200, make_excel(rows), 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet', True)
                elif url.path == '/api/stop':
                    self.reply(200, b'{}')
                    threading.Thread(target=self.server.shutdown, daemon=True).start()
                else:
                    self.reply(404, b'{}')
            except ValueError as e:
                self.reply(400, json.dumps({'error': str(e)}, ensure_ascii=False).encode())
            except Exception:
                self.reply(400, json.dumps({'error': 'Не удалось обработать документ. Проверьте, что это исправный .docx с текстом, а не скан или защищённый файл.'}, ensure_ascii=False).encode())

    return HTTPServer(('127.0.0.1', port), Handler)


def main():
    parser = argparse.ArgumentParser(description='Автономный конвертер списков Word → Excel')
    parser.add_argument('--no-browser', action='store_true')
    parser.add_argument('--port', type=int, default=0)
    args = parser.parse_args()
    server = create_server(args.port)
    url = f'http://127.0.0.1:{server.server_port}/'
    print('Программа работает только на этом компьютере. Для завершения нажмите «Завершить» в окне программы.')
    print('Если окно не открылось, откройте адрес в браузере:', url)
    if not args.no_browser:
        webbrowser.open(url)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        server.server_close()


if __name__ == '__main__':
    main()
